#include <stdio.h>



int main(){
Αρ
	float T, C, M, ft, cl;
	int choice;
	int choices;	
	float celcius, fahrenheit, euros,gbp,usd,amount, cny,kilos,lb;
	printf("Welcome to your Personal Convertor\n");

	printf("Enter your choise  (Press 1 :T for temperature,2: C for currency,3: M for Mass\n");
	scanf("%d",&choice);
		
	if(choice == 1){
		printf("\n 1:Convert Fahrenheit to Celcius");
		printf("\n 2:Convert Celcius to Fahrenheit");
		printf("Enter your choice(1,2):");
		scanf("%d",&choices);

		if(choices == 1){
			printf("\n Enter temperature in Fahrenheit:");
			scanf("%f", &ft);
			cl = (ft - 32) / 1.8;
			printf("Temperature is Celcius: %.2f", cl);
		}else if(choices == 2){
			printf("Enter temperature in Celcius");
			scanf("%f", &cl);
			ft = (cl * 1.8) + 32;
			printf("Temperature in Fahrenheit: %.2f", ft);
		}else{
			printf("Invalid choice");
		}
	}
	else if(choice == 2){
				
		printf("\n Convert Euro to USD.");
		printf("\n Convert Euro to GBP.");
		printf("\n Convert Euro to CNY.");
		printf("Enter your choices(1,2,3):");
		scanf("%d",&choices);
		if(choices == 1){

			printf("\nEnter Euros amount:");
			scanf("%f", &amount);
			
			euros = amount * 0.95;
			printf("\n%.2f Dollar = %.2f euros", amount,euros);
		}
		else if(choices == 2){
			printf("/n Enter Euros amount:");
			scanf("%f", &amount);
			euros = amount * 0.86;
			printf("\n %.2f GBP = %.2f euros", amount, gbp);
		}
		else if(choices == 3){
			printf("Enter euros amount:");
			scanf("%f", &amount);
			euros = amount *7.33;
			printf("\n %.2f CNY = %.2f euros", amount, cny);
		}else{
			printf("Invalid choice");
	
		}
	}
	else if(choice == 3){
		printf("Convert Kg to lb.\n");
		printf("Convert lb to Kg.\n");
		printf("Enter your choices (1,2)");
		scanf("%d",&choices);

		if(choices == 1){

		printf("Enter your Kg");
		scanf("%f", &kilos);	

		lb = kilos * 2.20462;

		printf("\n%.2f Kg = %.2f lb\n", kilos,lb);
		}else if(choices == 2){
			printf("Enter your lb:");
			scanf("%f",&lb);

			kilos = lb /2.20462;

		printf("\n %.2f lb = %.2f Kg", lb, kilos);

		}else{
			printf("Invalid choice");
		}

	}else{

		printf("Invalid choice");
	}

	
		printf("Bye Bye from your personal Convertor :)");

		return 0;
}

		 








